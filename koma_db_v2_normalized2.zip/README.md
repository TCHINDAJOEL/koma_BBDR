# KOMA Database v2.0 - Base de données normalisée

## 📋 Résumé de la migration

Cette version de la base de données KOMA a été entièrement réorganisée, normalisée et validée pour garantir la cohérence métier et l'intégrité des données.

### Statistiques de migration

| Table | Enregistrements | Statut |
|-------|-----------------|--------|
| materiaux | 367 | ✅ Conservée |
| metiers | 75 | 🆕 Nouvelle (fusion) |
| categories_metiers | 19 | 🆕 Nouvelle |
| prestations | 17 | 🆕 Nouvelle (fusion) |
| charges | 14 | ✅ Nettoyée |
| documents_chantier | 21 | 🆕 Nouvelle |
| equipements_securite | 11 | 🆕 Nouvelle |
| lots | 4 | ✅ Conservée |
| sections | 21 | ✅ Conservée |
| taches | 133 | ✅ Conservée |
| operations | 133 | ✅ Conservée |
| engins | 11 | ✅ Conservée |

---

## 🔄 Transformations effectuées

### 1. Migration des charges vers les tables appropriées

**Avant:** Table `charges` contenait 80 enregistrements hétérogènes mêlant :
- Outils de chantier (consommables)
- Personnel administratif
- Documents et plans
- Équipements de sécurité
- Charges générales

**Après:** Distribution dans les tables spécialisées :
- `materiaux` : Outils de chantier (déjà présents dans la table existante)
- `metiers` : Personnel administratif et technique
- `documents_chantier` : Plans, fiches, rapports
- `equipements_securite` : EPI et équipements HSE
- `charges` : Charges résiduelles (utilitaires, frais généraux)

### 2. Création de la table `metiers`

**Sources fusionnées :**
- Table `main_oeuvre` (59 enregistrements)
- Charges de type "Personnel administratif" (16 enregistrements)

**Structure enrichie :**
- Catégorisation hiérarchique (catégorie + sous-catégorie)
- Types de métier : ouvrier, ouvrier_qualifié, manoeuvre, encadrement
- Codification normalisée (MO-xxx, ADM-xxx)

### 3. Création de `categories_metiers`

Hiérarchie à deux niveaux :

```
📁 Gros-Oeuvre (GO)
├── Terrassement (GO-TER)
├── Ferraillage (GO-FER)
├── Coffrage (GO-COF)
├── Béton (GO-BET)
├── Maçonnerie (GO-MAC)
├── Enduits (GO-END)
├── Charpente-Couverture (GO-CHA)
└── Manutention (GO-MAN)

📁 Finitions (FIN)
├── Plafonds (FIN-PLA)
├── Carrelage (FIN-CAR)
├── Peinture (FIN-PEI)
├── Menuiserie (FIN-MEN)
├── Plomberie (FIN-PLB)
└── Électricité (FIN-ELE)

📁 Aménagement extérieur (EXT)
📁 Personnel administratif (ADM)
📁 Personnel technique (TECH)
```

### 4. Fusion `etudes` + `tarifs_koma` → `prestations`

**Unification des structures :**
- Études techniques (6 enregistrements)
- Tarifs KOMA (11 enregistrements)
- Discrimination par `type_prestation` : "etude" ou "tarif"

---

## 📊 Schéma de la base de données

### Tables principales

| Table | Description | PK |
|-------|-------------|-----|
| lots | Lots de travaux BTP | lot_id |
| sections | Sections regroupant les tâches | section_id |
| taches | Unité centrale planning/devis | tache_id |
| operations | Actions concrètes | operation_id |

### Tables ressources

| Table | Description | PK |
|-------|-------------|-----|
| materiaux | Matériaux de construction | materiau_id |
| metiers | Main d'œuvre et personnel | metier_id |
| engins | Équipements de chantier | engin_id |
| categories_metiers | Catégorisation des métiers | categorie_metier_id |
| categories_materiaux | Catégorisation des matériaux | categorie_id |

### Tables de liaison

| Table | Description | Relations |
|-------|-------------|-----------|
| operation_materiaux | Consommation matériaux | operation → materiaux |
| operation_metiers | Affectation main d'œuvre | operation → metiers |
| operation_engins | Utilisation engins | operation → engins |

### Tables complémentaires

| Table | Description |
|-------|-------------|
| prestations | Études et tarifs unifiés |
| charges | Charges et frais généraux |
| documents_chantier | Plans et documents |
| equipements_securite | EPI et HSE |
| utilitaires_materiel | Carburant, eau, électricité |

---

## 🔗 Relations clés

```
lots ─────────────────┐
     │                │
     ▼                │
sections ─────────────┤
     │                │
     ▼                │
taches ───────────────┤
     │                │
     ▼                │
operations ───────────┴──────┬──────────┬──────────┐
     │                       │          │          │
     ▼                       ▼          ▼          ▼
operation_materiaux    operation_metiers    operation_engins
     │                       │                    │
     ▼                       ▼                    ▼
materiaux                 metiers              engins
                            │
                            ▼
                    categories_metiers
```

---

## 📁 Fichiers livrés

### Données (format JSON)
- `materiaux.json` - Matériaux et consommables
- `metiers.json` - Métiers et main d'œuvre
- `categories_metiers.json` - Catégories de métiers
- `prestations.json` - Études et tarifs fusionnés
- `charges.json` - Charges générales
- `documents_chantier.json` - Documents et plans
- `equipements_securite.json` - EPI et sécurité
- `lots.json`, `sections.json`, `taches.json`, `operations.json`
- `operation_materiaux.json`, `operation_engins.json`
- `engins.json`, `utilitaires_materiel.json`
- `categories_materiaux.json`, `unites.json`
- `types_projet.json`, `profils_utilisateurs.json`

### Documentation
- `database_schema.json` - Schéma complet de la base
- `database_erd.mermaid` - Diagramme entité-relation
- `migration_summary.json` - Résumé de la migration
- `README.md` - Ce fichier

---

## ✅ Validation de cohérence

Tous les enregistrements ont été validés selon les critères suivants :
- ✅ Conformité à la table d'appartenance
- ✅ Validité des clés étrangères
- ✅ Cohérence des montants et unités
- ✅ Absence de valeurs aberrantes
- ✅ Alignement catégorie/usage métier

**Résultat : 0 anomalie détectée**

---

## 🚀 Utilisation

### Importer les données

```python
import json

def load_table(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        data = json.load(f)
        return data['records']

# Exemple
metiers = load_table('metiers.json')
for m in metiers:
    print(f"{m['code_metier']}: {m['designation']}")
```

### Requêtes courantes

**Trouver les métiers de Gros-Œuvre :**
```python
gros_oeuvre = [m for m in metiers if m['categorie_metier_id'] == 1]
```

**Calculer le coût total d'une prestation :**
```python
prestations = load_table('prestations.json')
etudes = [p for p in prestations if p['type_prestation'] == 'etude']
total = sum(p['cout_total'] for p in etudes)
```

---

## 📝 Notes de version

**Version 2.0** (décembre 2024)
- Migration complète depuis la base Excel
- Normalisation des tables
- Création des catégories hiérarchiques
- Fusion des données redondantes
- Validation de cohérence globale

---

## 👤 Auteur

Généré automatiquement par le système de migration KOMA Database.
